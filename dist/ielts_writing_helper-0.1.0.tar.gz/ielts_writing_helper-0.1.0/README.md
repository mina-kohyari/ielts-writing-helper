# IELTS Writing Helper

A Python CLI tool to analyze IELTS essays and give estimated band scores.

## Installation
pip install -e .

## Usage
ielts check essay.txt
ielts check essay.txt --json

## License
MIT